package com.vending.vendingmachine.repo;

import com.vending.vendingmachine.model.PurchaseLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface LogRepo extends JpaRepository<PurchaseLog, Long> {
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value="INSERT INTO vendingmachinetesting.purchase_log (purchase_date, product_code, product_count, product_purchased) VALUES (current_timestamp(), :productCode, :productCount, :productName);", nativeQuery = true)
    void addPurchaseLog(@Param("productName")String productName, @Param("productCode")int productCode, @Param("productCount") int productCount);
}
