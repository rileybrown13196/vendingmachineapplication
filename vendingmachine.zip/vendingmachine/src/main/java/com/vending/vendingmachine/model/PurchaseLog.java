package com.vending.vendingmachine.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
public class PurchaseLog implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false, updatable = false)
    private Long id;
    private String productPurchased;
    private int productCount;
    private int productCode;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime purchaseDate;


    public PurchaseLog(){}

    public PurchaseLog(String productPurchased, int productCount, int productCode, LocalDateTime purchaseDate){
        this.productPurchased = productPurchased;
        this.productCount = productCount;
        this.productCode = productCode;
        this.purchaseDate = purchaseDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductPurchased() {
        return productPurchased;
    }

    public void setProductPurchased(String productPurchased) {
        this.productPurchased = productPurchased;
    }

    public int getProductCount() {
        return productCount;
    }

    public void setProductCount(int productCount) {
        this.productCount = productCount;
    }

    public int getProductCode() { return productCode; }

    public void setProductCode(int productCode) { this.productCode = productCode; }

    public LocalDateTime getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDateTime purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    @Override
    public String toString() {
        return "ProductPurchasedLog{" +
                ", productPurchased='" + productPurchased + "\'" +
                ", productCount='" + productCount + "\'" +
                ", productCode='" + productCode + "\'"+
                ", date='" + purchaseDate + "\'" +
                '}';
    }
}