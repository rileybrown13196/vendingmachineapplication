package com.vending.vendingmachine.service;

import com.vending.vendingmachine.exception.ProductNotFoundException;
import com.vending.vendingmachine.model.PurchaseLog;
import com.vending.vendingmachine.repo.LogRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LoggingService {
    private final LogRepo logRepo;

    @Autowired
    public LoggingService(LogRepo logRepo){
        this.logRepo = logRepo;
    }


    public void addToPurchaseLog(PurchaseLog purchaseLog){
//        return logRepo.save(purchaseLog);
        String productName = purchaseLog.getProductPurchased();
        int productCode = purchaseLog.getProductCode();
        int productCount = purchaseLog.getProductCount();
        logRepo.addPurchaseLog(productName, productCode, productCount);
    }
}
