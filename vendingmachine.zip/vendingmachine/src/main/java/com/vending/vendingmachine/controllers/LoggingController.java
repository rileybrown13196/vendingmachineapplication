package com.vending.vendingmachine.controllers;

import com.vending.vendingmachine.model.Product;
import com.vending.vendingmachine.model.PurchaseLog;
import com.vending.vendingmachine.service.LoggingService;
import com.vending.vendingmachine.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/logging")
public class LoggingController {
    private final LoggingService loggingService;

    public LoggingController(LoggingService loggingService){
        this.loggingService = loggingService;
    }

    @PostMapping("/addProductLog")
    public ResponseEntity<?> addProductLog(@RequestBody PurchaseLog purchaseLog) {
        loggingService.addToPurchaseLog(purchaseLog);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
