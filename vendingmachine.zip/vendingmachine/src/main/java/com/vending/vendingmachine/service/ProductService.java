package com.vending.vendingmachine.service;

import com.vending.vendingmachine.model.Product;
import com.vending.vendingmachine.repo.ProductRepo;
import com.vending.vendingmachine.exception.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    private final ProductRepo productRepo;

    @Autowired
    public ProductService(ProductRepo productRepo){
        this.productRepo = productRepo;
    }

    public List<Product> findAllProducts() {
        return productRepo.findAll();
    }
    public Product addProduct(Product product){
        return productRepo.save(product);
    }
    public Integer updateProductCountById(int productCode){
        return productRepo.updateProductCountByProductCode(productCode);
    }
    public Product getProductInfoById(Long id){
        return productRepo.getProductInfoById(id).orElseThrow(() -> new ProductNotFoundException("Product by id " + id + " was not found"));
    }
}
