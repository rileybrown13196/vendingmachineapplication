package com.vending.vendingmachine.model;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
public class Product implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)
    private Long id;
    private String productName;
    private int productCount;
    private String imageUrl;

    private int productCode;

    public Product(){}

    public Product(String productName, int productCount, String imageUrl, int productCode){
        this.productName = productName;
        this.productCount = productCount;
        this.imageUrl = imageUrl;
        this.productCode = productCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductCount() {
        return productCount;
    }

    public void setProductCount(int productCount) {
        this.productCount = productCount;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getProductCode() { return productCode; }

    public void setProductCode(int productCode) { this.productCode = productCode; }

    @Override
    public String toString() {
        return "Product{" +
                ", productName='" + productName + "\'" +
                ", productCount='" + productCount + "\'" +
                ", imageUrl='" + imageUrl + "\'" +
                ", productCode='" + productCode + "\'"+
                '}';
    }
}
