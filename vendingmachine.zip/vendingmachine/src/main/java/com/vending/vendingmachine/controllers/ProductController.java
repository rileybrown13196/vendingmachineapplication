package com.vending.vendingmachine.controllers;

import com.vending.vendingmachine.model.Product;
import com.vending.vendingmachine.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {
    private final ProductService productService;

    public ProductController(ProductService productService){
        this.productService = productService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<Product>> getAllEmployees() {
        List<Product> findAllProducts = productService.findAllProducts();
        return new ResponseEntity<>(findAllProducts, HttpStatus.OK);
    }

    // For testing purposes and possible functionality of vendor page to add a new product
    @PostMapping("/addProduct")
    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
        Product newProduct = productService.addProduct(product);
        return new ResponseEntity<>(newProduct, HttpStatus.CREATED);
    }

    // Added for possible future functionality
    @GetMapping("/getProductInfoById/{id}")
    public ResponseEntity<Product> getProductInfoById(@PathVariable("id") Long id) {
        Product getProductCt = productService.getProductInfoById(id);
        return new ResponseEntity<>(getProductCt, HttpStatus.OK);
    }

    @PutMapping("/updateProductCount/{productCode}")
    public ResponseEntity<Integer> updateProductCountById(@PathVariable("productCode") int productCode) {
        Integer updateCount = productService.updateProductCountById(productCode);
        return new ResponseEntity<>(updateCount, HttpStatus.OK);
    }
}
