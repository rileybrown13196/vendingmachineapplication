import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertQuarterComponent } from './insert-quarter.component';

describe('InsertQuarterComponent', () => {
  let component: InsertQuarterComponent;
  let fixture: ComponentFixture<InsertQuarterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertQuarterComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertQuarterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
