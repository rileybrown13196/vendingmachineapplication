export class ProductUpdateRequestModel {
  id: number;
  productCount: number;
  productCode: number;
  productName: string;
  imageUrl: string;
  constructor(productUpdateRequest?: ProductUpdateRequestModel) {
    this.id = 0;
    this.productCount=0;
    this.productCode=0;
    this.productName = "";
    this.imageUrl = "";
    if(productUpdateRequest){
      Object.assign(this, productUpdateRequest);
    }
  }
}
