import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { InsertQuarterComponent } from './insert-quarter/insert-quarter.component';

import { BalanceService } from './balance/balance.service';
import { ProductService } from './product/product.service';
import { DispenseProductComponent } from './dispense-product/dispense-product.component';
import { SelectProductComponent } from './select-product/select-product.component';
import { ProductsComponent } from './products/products.component';

@NgModule({
  declarations: [
    AppComponent,
    InsertQuarterComponent,
    DispenseProductComponent,
    SelectProductComponent,
    ProductsComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    BalanceService,
    ProductService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
