import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product/product.service';
import { BalanceService } from '../balance/balance.service';

@Component({
  selector: 'app-dispense-product',
  templateUrl: './dispense-product.component.html',
  styleUrls: ['./dispense-product.component.css'],
  providers: [],
})
export class DispenseProductComponent implements OnInit {
  itemSelected = false;
  constructor(private productService: ProductService, private balanceService: BalanceService) { }

  ngOnInit() { }

  dispenseProduct() {
    const currentBalance = this.balanceService.getBalance();
    if(!this.productIsSelected()) return;
    if(!this.hasSufficientBalance(currentBalance)) return;
    if(!this.hasRemaining()){
      alert("remaining is false : " + this.hasRemaining());
      return;
    }
    this.productService.dispenseItem((product: { productName: string; }) => {
      alert('Enjoy your ' + this.productService.productNameForMessage);
      this.balanceService.ejectOrDeductQuarter(0.25);
    });
  }

  productIsSelected() {
    const productIsSelected = !!this.productService.getSelectedProduct();
    if(!productIsSelected) alert('No item selected');
    return productIsSelected;
  }

  hasSufficientBalance(currentBalance: number) {
    const hasBalance = this.productService.hasSufficientBalance(currentBalance);
    if(!hasBalance) alert('Insufficient balance');
    return hasBalance;
  }

  hasRemaining() {
    const remaining = this.productService.hasRemaining();
    if(!remaining) alert('No remaining inventory for this item');
    this.productService.setProductCount(0);
    return remaining;
  }
}
