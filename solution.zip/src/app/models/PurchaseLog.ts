export interface PurchaseLog {
  productPurchased: string;
  productCountLog: number;
  productCodeLogging: number;
}
