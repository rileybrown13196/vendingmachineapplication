export const environment = {
  production: false,
  apiBaseurl: 'http://localHost:8080'
};
