import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs';

@Injectable()
export class BalanceService {
  private balance: number = 0;
  private subject: Subject<number> = new Subject<number>();

  constructor() { }

  private updateSubject(): void {
    this.subject.next(this.balance);
  }

  setBalance(amount: number): void {
    this.balance = amount;
    this.updateSubject();
  }

  getBalance(): number {
    return this.balance;
  }

  addQuarter(amount: number): void {
    this.balance += amount;
    this.updateSubject();
  }

  ejectOrDeductQuarter(amount: number): void {
    this.balance -= amount;
    this.updateSubject();
  }

  onBalanceUpdated(callback: (balance: any) => void): void {
    this.subject.asObservable().subscribe(callback);
  }
}
