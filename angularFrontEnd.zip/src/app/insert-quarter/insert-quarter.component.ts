import { Component, OnInit } from '@angular/core';
import { BalanceService } from '../balance/balance.service';

@Component({
  selector: 'app-insert-quarter',
  templateUrl: './insert-quarter.component.html',
  styleUrls: ['./insert-quarter.component.css'],
  providers: []
})
export class InsertQuarterComponent implements OnInit {
  quarterBalance = 0;
  hasBalanceBoolean = true;
  constructor(public balanceService: BalanceService) { }

  ngOnInit() {
    this.balanceService.onBalanceUpdated((balance) => {
      this.quarterBalance = balance;
      this.hasBalanceBoolean = (balance <= 0);
    });
  }

  addBalance(amount: number) {
    this.balanceService.addQuarter(amount);
  }
  ejectQuarter(amount: number) {
    this.balanceService.ejectOrDeductQuarter(amount);
  }
}
