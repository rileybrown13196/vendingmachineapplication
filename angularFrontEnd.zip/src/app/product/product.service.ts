import { Injectable } from '@angular/core';
import {catchError, Observable, pipe, Subscription} from 'rxjs';
import {HttpClient, HttpHeaders, HttpResponse, HttpResponseBase} from '@angular/common/http';
import {environment} from "../../environments/environment";
import {Product} from "../product";
import {ProductsComponent} from "../products/products.component";
import {ProductUpdateRequestModel} from "../product-update-request.model";
import {PurchaseLog} from "../models/PurchaseLog";

@Injectable()
export class ProductService {
  private apiServerUrl = environment.apiBaseurl;
  private getProductsUrl = this.apiServerUrl + "/product/all";
  private addProductUrl = this.apiServerUrl + "/product/addProduct";
  private updateProductCountUrl = this.apiServerUrl + "/product/updateProductCount/";
  private deleteProductUrl = this.apiServerUrl + "";
  private purchaseLogUrl = this.apiServerUrl + "/logging/addProductLog";
  private purchaseLog: any;
  private productsComponent = ProductsComponent;
  private selectedProduct: any;
  private productCountForSoldOut: any;
  private selectedProductLogging: any;
  public productNameForMessage: string;
  private purchaseLogCreation: PurchaseLog;
  private productCountForLog: number;
  private productNameForLog: string;
  constructor(private http: HttpClient) {}

  public getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.getProductsUrl}`);
  }

  onItemsRetrieved(callback: any): void {
    this.getProducts().subscribe(callback);
  }

  getSelectedProduct(): any {
    return this.selectedProduct;
  }

  setSelectedProduct(product: any): void {
    this.selectedProduct = product;
  }

  // Not yet used. Add for possibility of vendor page
  public addProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(`${this.addProductUrl}`, product);
  }

  public addToPurchaseLog(purchaseLog: PurchaseLog): Observable<void> {
    return this.http.post<void>(`${this.purchaseLogUrl}`, purchaseLog);
  }

  public updateProductCount(productCode: number): Observable<number> {
    return this.http.put<number>(`${this.updateProductCountUrl}${this.selectedProduct.productCode}`, productCode);
  }

  dispenseItem(callback: any): void {
    this.selectedProductLogging.productCountForLog = 1;
    this.selectedProductLogging.productNameForLog = this.selectedProduct.productName;
    this.productNameForMessage = this.selectedProduct.productName;
    this.updateProductCount(this.selectedProduct).subscribe(callback);
    this.addToPurchaseLog(this.selectedProductLogging);
    this.selectedProduct.productCount -=1;
    this.setProductCount(this.selectedProduct.productCount);

  }
  hasSufficientBalance(currentBalance: number): boolean {
    if(!this.selectedProduct) return false;
    const hasSufficientBalance = (currentBalance >= 0.25);
    return hasSufficientBalance;
  }

  hasRemaining(): boolean {
    return this.selectedProduct && this.selectedProduct.productCount > 0;
  }

  setLoggingProduct(productLog: any): void {
    this.selectedProductLogging = productLog;
  }

  getProductCount(): number {
    return this.productCountForSoldOut;
  }

  setProductCount(count: number): void {
    this.productCountForSoldOut = count;
  }
}
