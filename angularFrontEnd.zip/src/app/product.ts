export interface Product {
  productId: number;
  productName: string;
  productCount: number;
  imageUrl: string;
  productCode: number;

}
