import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DispenseProductComponent } from './dispense-product.component';

describe('DispenseItemComponent', () => {
  let component: DispenseProductComponent;
  let fixture: ComponentFixture<DispenseProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DispenseProductComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DispenseProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
