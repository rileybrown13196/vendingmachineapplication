import { Component, OnInit } from '@angular/core';
import {ProductService} from "../product/product.service";
import {Product} from "../product";

@Component({
  selector: 'app-select-product',
  templateUrl: './select-product.component.html',
  styleUrls: ['./select-product.component.css'],
  providers: []
})
export class SelectProductComponent implements OnInit {
  products: Product[] =[];
  productCode: 0;

  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.productService.onItemsRetrieved((products: Product[]) => this.products = products);
  }

  onClickSubmit(data: { productCode: number; }) {
    this.products.forEach((product) => {
      if (product.productCode == data.productCode) {
        this.productService.setSelectedProduct(product);
        alert(`${product.productName} has been selected.`)
        this.productService.setLoggingProduct(product);
      }
    });
  }
}
